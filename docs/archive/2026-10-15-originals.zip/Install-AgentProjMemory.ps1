#requires -Version 5.1
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [Parameter(Mandatory = $false)]
    [string]$Destination = 'C:\Users\Administrator\Desktop\tool\agentProj'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$payloadRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'agentProj'))
$manifestPath = Join-Path $PSScriptRoot 'payload-manifest.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    throw 'Missing payload-manifest.json. Extract the complete ZIP first.'
}
$manifest = Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($manifest.schema_version -ne 1 -or $manifest.kind -ne 'agentProj_discussion_memory_payload') {
    throw 'Unsupported payload manifest.'
}

$destinationRoot = [System.IO.Path]::GetFullPath($Destination)
$separators = [char[]]@([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
$sourcePrefix = $payloadRoot.TrimEnd($separators) + [System.IO.Path]::DirectorySeparatorChar
$destinationPrefix = $destinationRoot.TrimEnd($separators) + [System.IO.Path]::DirectorySeparatorChar
$toCopy = @()
$unchanged = 0

# Validate every source and destination before copying any file.
foreach ($entry in $manifest.files) {
    $relative = [string]$entry.path
    if ([System.IO.Path]::IsPathRooted($relative)) {
        throw "Expected a relative path: $relative"
    }
    $source = [System.IO.Path]::GetFullPath((Join-Path $payloadRoot $relative))
    $target = [System.IO.Path]::GetFullPath((Join-Path $destinationRoot $relative))
    if (-not $source.StartsWith($sourcePrefix, [System.StringComparison]::OrdinalIgnoreCase) -or
        -not $target.StartsWith($destinationPrefix, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Path is outside the selected directory: $relative"
    }
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) {
        throw "Missing payload file: $relative"
    }
    $sourceHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    if ($sourceHash -ne $entry.sha256) {
        throw "Payload checksum mismatch: $relative"
    }
    if (Test-Path -LiteralPath $target) {
        if (-not (Test-Path -LiteralPath $target -PathType Leaf)) {
            throw "A directory conflicts with the target file: $target"
        }
        $targetHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
        if ($targetHash -ne $entry.sha256) {
            throw "Existing file has different content. Nothing was copied: $target"
        }
        $unchanged++
    } else {
        $toCopy += [pscustomobject]@{ Source = $source; Target = $target; Hash = $entry.sha256 }
    }
}

if ($toCopy.Count -eq 0) {
    Write-Host "Already present: $unchanged identical files."
    Write-Host "Destination: $destinationRoot"
    return
}
if (-not $PSCmdlet.ShouldProcess($destinationRoot, "Copy $($toCopy.Count) discussion memory files without overwriting existing files")) {
    return
}

foreach ($item in $toCopy) {
    $parent = [System.IO.Path]::GetDirectoryName($item.Target)
    [System.IO.Directory]::CreateDirectory($parent) | Out-Null
    # false means a concurrently created target will not be overwritten.
    [System.IO.File]::Copy($item.Source, $item.Target, $false)
    $copiedHash = (Get-FileHash -LiteralPath $item.Target -Algorithm SHA256).Hash
    if ($copiedHash -ne $item.Hash) {
        throw "Post-copy checksum mismatch: $($item.Target)"
    }
}

Write-Host "Saved $($toCopy.Count) files; skipped $unchanged identical files."
Write-Host "Destination: $destinationRoot"
Write-Host "Start with: $(Join-Path $destinationRoot 'README_AGENTPROJ_MEMORY_20261015.md')"
