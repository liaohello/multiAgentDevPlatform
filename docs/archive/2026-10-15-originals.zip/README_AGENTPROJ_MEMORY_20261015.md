# agentProj 讨论记忆入口

整理日期：2026-10-15（America/Los_Angeles）。目标项目目录：`C:\Users\Administrator\Desktop\tool\agentProj`。

这是 Windows Sol + WSL DeepSeek 开发工作台的讨论记忆与交接资料，尚不是软件实现或验收报告。文档按中文整理，区分用户明确要求、推荐方案与待核验事项。

## 从哪里开始

1. 阅读 [项目整体记忆](docs/discussion-memory-2026-10-15/PROJECT_MEMORY.md)。
2. 核对 [决策与待确认事项](docs/discussion-memory-2026-10-15/DECISIONS_AND_OPEN_QUESTIONS.md)。
3. 实施前阅读 [分期实施与验收](docs/discussion-memory-2026-10-15/IMPLEMENTATION_PLAN.md)。
4. 交给本地 Codex 时使用 [交接提示词](docs/discussion-memory-2026-10-15/CODEX_HANDOFF.md)。

补充资料：

- [数据与事件约定](docs/discussion-memory-2026-10-15/DATA_CONTRACTS.md)
- [Skill 候选与核验清单](docs/discussion-memory-2026-10-15/SKILL_CANDIDATES.md)
- [结构化记忆索引](docs/discussion-memory-2026-10-15/MEMORY_INDEX.json)
- [来源与本次落盘状态](docs/discussion-memory-2026-10-15/SOURCE_AND_DELIVERY.md)

## 使用边界

- 本资料汇总了当前可见讨论和历史上下文检索结果，不冒充完整逐字聊天备份。
- 示例 JSON 均为模拟数据，不代表真实运行、真实 Token 消耗或已完成的功能。
- 本次没有安装第三方 Skill，没有验证其仓库内容，也没有编写或部署工作台。
- 没有新增或覆盖项目根目录 `AGENTS.md`，没有把候选 Skill 自动变成工程强制规则。
- 后续实现时，以实际仓库、运行环境与用户后续决定为准；修改已确定要求时记录变更原因。
