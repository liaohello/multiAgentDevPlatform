# agentProj 讨论记忆包

目标：将 2026-10-15 关于 Windows Sol + WSL DeepSeek 开发工作台的整体讨论保存为本地项目资料。

## 保存到指定 Windows 目录

1. 完整解压此 ZIP 到任意临时目录。
2. 在解压目录打开 PowerShell，运行：

```powershell
& .\Install-AgentProjMemory.ps1
```

默认目标为：

`C:\Users\Administrator\Desktop\tool\agentProj`

脚本仅校验和复制资料，不联网、不安装依赖、不启动 Agent、不修改系统设置。已存在相同内容时跳过，存在不同内容的同名文件时停止，不覆盖。若中途因磁盘或权限问题停止，已完成的资料仍保留，排除原因后可重新运行。

可选预览：

```powershell
& .\Install-AgentProjMemory.ps1 -WhatIf
```

如果本机执行策略阻止脚本，不需要更改系统策略：也可使用资源管理器把包内 `agentProj` 文件夹中的内容复制到目标目录；遇到同名文件先比较，勿直接覆盖。

完成后，从目标目录的 `README_AGENTPROJ_MEMORY_20261015.md` 开始阅读。

## 包内内容

- `agentProj/`：实际需要保存在项目里的记忆文件。
- `Install-AgentProjMemory.ps1`：仅复制资料的落盘脚本，支持 Windows PowerShell 5.1 及以上。
- `payload-manifest.json`：资料文件 SHA-256 完整性清单。
- `SHA256SUMS.txt`：整个解压包的文件校验清单（不含清单自身）。

文档覆盖架构分工、工作目录/会话/Wiki 隔离、输出与记忆边界、Skill 管理、四种专用工作流、Goal 全链复盘、Token/预算停止、数据对象、实施验收与 Codex 交接。JSON 示例均为模拟，不是已运行数据。

本包是在 Linux 执行环境生成的；PowerShell 脚本经过内容审查，但未在真实 Windows PowerShell 运行。生成文档包不等于已写入用户的 C 盘，需以上述本地复制结果为准。
