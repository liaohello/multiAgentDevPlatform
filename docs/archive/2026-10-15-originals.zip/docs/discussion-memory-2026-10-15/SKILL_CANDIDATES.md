# Skill 候选来源与核验记录

这些是讨论中的候选，不是本次安装结果。本次任务仅整理记忆，没有联网逐项复核、拉取、执行或安装任何第三方 Skill。原回答的部分图卡链接与 Skill 名称/仓库不一致，应重新核验实际文件。

## 1. 与最小方案直接相关的候选

| 名称 | 原讨论提及的仓库标识 | 期望能力 | 本次状态 |
| --- | --- | --- | --- |
| unslop | `maxgoff/unslop`；另出现 `MohamedAbdallah-14/unslop` | 减少 AI 冗余代码与无必要防御 | 两个来源可能不同，不能混为一项；待核验 |
| minimalist | `alirezarezvani/claude-skills` | YAGNI、复用、控制依赖与复杂度 | 具体目录与同名 Skill 存在性待核验 |
| codebase-design | `mattpocock/skills` | 模块边界、接口与浅包装问题 | 文件路径、内容和许可证待核验 |
| agentic-architecture | `Lightbridge-KS/agent-stuff` | Agent 循环、工具、记忆、生命周期 | 文件路径、兼容性待核验 |
| code-simplifier | `caarlos0/dotfiles` | 限定当前 Diff、保持行为的简化 | 具体文件与约束待核验 |
| Skill 安装工具 | `vercel-labs/skills` | 查找和安装指定 Skill | 实际版本、参数与下载/执行行为待核验 |

这里的仓库标识按历史讨论保留，不代表其内容真实存在、符合描述或当前适合安装。为避免复制未经核验的命令，本资料不把原 `npx skills add` 命令作为可直接执行步骤。

## 2. 其他讨论过的候选

| 名称 / 仓库标识 | 讨论用途 | 处理意见 |
| --- | --- | --- |
| linus-guidelines | 控制复杂度与特殊情况的评审视角 | 未有可靠文件路径；不代表 Linus 本人背书 |
| codebase-architecture | 目录、契约、依赖边界 | 精确来源未确定 |
| architecture-patterns | Clean / Hexagonal / DDD 等 | 不应因此强制上复杂架构 |
| adr-skill | 重大架构决策记录 | 只在需要时采用 |
| deep-codebase-analysis | 已有项目结构、调用链与错误处理分析 | 精确来源未确定 |
| `obra/superpowers` | brainstorming、planning、TDD、review | 工作流较强，简单任务不强制整套 |
| `imadnan4/architect-skills` | 一组架构类 Skill | 内容与成熟度未在本次验证 |
| `cheriftj/c4-model-skill` | C4 架构图 | 原图卡与其他条目混用，不作为安装依据 |

历史检索还提到四种专用工作流的参考标识：`getsentry/prompt-optimizer`、`openai/define-goal`、`agent-retro`、`tomzx/verify-pr`、`bm629/token-optimization`。其中部分并非完整仓库路径，且没有在本次读取对应内容，仅保留为后续检索线索。

## 3. 导入一个 Skill 时需要记录什么

1. 确认仓库、作者、具体目录及真正的 `SKILL.md`，先读内容再选择。
2. 固定 commit 和文件哈希；保留许可证、依赖和支持环境。
3. 区分纯指令与带脚本/外部工具的 Skill；核对网络、文件、凭据和命令需求。
4. 先导入到 Registry，经项目允许和会话选择后再提供给运行时。
5. 用一个小任务验证触发、输出与对代码的影响；不要一次全局安装一套。
6. 记录安装、提供、观察到的调用、相关 Run 和结果；未知项不伪造。

导入/安装本身不是执行授权；Skill 脚本也不能获得超出该 Run 的权限。后续若实际采用某第三方 Skill，应补上真实 URL、commit、文件路径、核验日期与结论。
