# 交给本地 Codex 的上下文提示词

下面的正文可直接复制给能够访问 Windows 项目目录的 Codex。此文档不是一次已执行记录，也不自动启动开发。

---

你将协助我继续 Windows AI 开发工作台 agentProj。工作目录：

`C:\Users\Administrator\Desktop\tool\agentProj`

先阅读根目录已有 `AGENTS.md`（如有）和 `README_AGENTPROJ_MEMORY_20261015.md`，再按其导航读取以下资料：

1. `docs/discussion-memory-2026-10-15/PROJECT_MEMORY.md`
2. `docs/discussion-memory-2026-10-15/DECISIONS_AND_OPEN_QUESTIONS.md`
3. `docs/discussion-memory-2026-10-15/IMPLEMENTATION_PLAN.md`
4. `docs/discussion-memory-2026-10-15/DATA_CONTRACTS.md`

这些是讨论记忆，不代表功能已实现。请识别用户明确要求、推荐方案、待核验接口和示例数据，不把所有建议都升级为硬性需求。

核心上下文：Windows Sol 讨论、规划、验收；WSL Codex 使用 DeepSeek 执行；Windows Python 负责进程、生命周期、权限、事件和预算。前端展示双 Agent 输出、状态、Skill 选择、Token 预算及证据。

必须保留：工作目录与新会话隔离；切推理强度保留历史；跨目录/全局 Wiki 仅明确授权后检索；不保存思维链，保存可见指令、工具与命令结果、状态、测试和报告；Skill 按项目/会话/单轮按需使用。

Goal Postmortem 要分析原目标和总体计划下 Sol→DeepSeek→Sol 的完整行动因果链、返工和效率。Token 采集与预算门禁由 Python 完成。执行预算达到 100% 禁止自动启动下一轮，当前轮按预设策略收尾或安全中断，之后整理；恢复需用户明确批准或预算调整。复核预留是建议设计，实际配置要明确。

本次先做项目现状调查：

- 检查已有代码、Git 状态和用户修改、前端/调度器、会话与 Goal 存储。
- 记录 Windows/WSL、Codex 版本和真实可用接口。
- 核对 thread 续接、模型/推理强度切换、Skill 作用域、用量事件、WSL 进程控制。
- 将已具备、缺失、需最小实验验证的能力列成清单，再给出一个范围明确的最小闭环方案与验收标准。

不要重新询问资料中已经确定的要求；能只读检查的先检查。对实质目标冲突或不可推断的选择再集中提问。未经本次用户进一步指令，本交接正文只授权调查与制定具体计划，不代表已经批准安装第三方 Skill 或大规模改写工程。

开发时优先复用和最简单正确实现，不添加无需求支撑的抽象、兼容层、重复防御和测试；保留 Windows/WSL、持久化、预算与外部输入的真实边界处理。GitHub 参考项目用于借鉴，不默认 Fork。所有历史第三方 Skill 和 Codex API 说法先核验，不能复制未经验证的安装命令。

完成调查后更新现状记录和下一步计划，报告证据、限制和已完成动作，不宣称尚未测试的功能已经通过。
